<?php
/**
 * The template for displaying the footer
 */

wp_footer(); ?>

</body>
</html>
