<?php
/*
 * The template for displaying 404 pages (not found)
 */

get_header();
esc_html_e('404', 'sp-theme');
esc_html_e('Page not found', 'sp-theme');
get_footer();