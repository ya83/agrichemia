Theme Name: SP Theme

Theme URI: https://cms3.ru/wordpress-pustaya-tema/

Author: Alex Kuimov

Author URI: https://cms3.ru

Description: The blank wordpress theme

Version: 1.0.0

Text Domain: sp-theme

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html
