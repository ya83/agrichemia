=== SP Theme ===
Contributors: Alex Kuimov
Requires at least: WordPress 4.9
Tested up to: WordPress 4.9-trunk
Version: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, news, two-columns, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, translation-ready

== Description ==
The blank wordpress theme

== Installation ==

1. Copy the theme folder to /wp-content/themes/
2. Activate the theme

== Copyright ==

Font Awesome icons, Copyright Dave Gandy
License: SIL Open Font License, version 1.1.
Source: http://fontawesome.io/

Lazy Load, Copyright Mika Tuupola
License: MIT License
Source: https://appelsiini.net/projects/lazyload

Swiper, Copyright Vladimir Kharlampidi
License: MIT License
Source: http://www.idangero.us/swiper/

WOW, Matt Dellac
License: GNU GPLv3
Source: https://github.com/matthieua/WOW

Font Awesome Icon Picker, Javi Aguilar
License: MIT License
Source: https://farbelous.github.io/fontawesome-iconpicker/

== Changelog ==

= 1.0 =
* Released: November 06, 2018

Initial release